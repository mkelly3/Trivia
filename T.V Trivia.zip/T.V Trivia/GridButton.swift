//
//  GridButton.swift
//  T.V Trivia
//
//  Created by mkelly2 on 12/8/15.
//  Copyright © 2015 mkelly2. All rights reserved.
//

import UIKit

class GridButton: UIButton {
var canTap = true
    

}
